package br.com.estetica.controller;

import br.com.estetica.service.TipoServicoService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class TipoServicoController {

    private final TipoServicoService tipoServicoService;

    public TipoServicoController(TipoServicoService tipoServicoService) {
        this.tipoServicoService = tipoServicoService;
    }

    @GetMapping("/servicos")
    public String listar(Model model, HttpSession session) {
        if (session.getAttribute("usuarioLogado") == null) {
            return "redirect:/login";
        }

        model.addAttribute("servicos", tipoServicoService.listarTodos());
        model.addAttribute("perfil", session.getAttribute("perfil"));

        return "servicos";
    }

    @GetMapping("/servicos/novo")
    public String novo(HttpSession session) {
        if (session.getAttribute("usuarioLogado") == null) {
            return "redirect:/login";
        }

        if (!"GESTOR".equals(session.getAttribute("perfil"))) {
            return "redirect:/home";
        }

        return "servico-form";
    }

    @PostMapping("/servicos")
    public String salvar(@RequestParam("nome") String nome,
                         @RequestParam("descricao") String descricao,
                         @RequestParam("preco") Double preco,
                         HttpSession session,
                         Model model) {
        if (session.getAttribute("usuarioLogado") == null) {
            return "redirect:/login";
        }

        if (!"GESTOR".equals(session.getAttribute("perfil"))) {
            return "redirect:/home";
        }

        try {
            tipoServicoService.cadastrar(nome, descricao, preco);
            return "redirect:/servicos";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "servico-form";
        }
    }

    @GetMapping("/servicos/desativar/{id}")
    public String desativar(@PathVariable("id") String id, HttpSession session) {
        if (session.getAttribute("usuarioLogado") == null) {
            return "redirect:/login";
        }

        if (!"GESTOR".equals(session.getAttribute("perfil"))) {
            return "redirect:/home";
        }

        tipoServicoService.desativar(id);
        return "redirect:/servicos";
    }
}
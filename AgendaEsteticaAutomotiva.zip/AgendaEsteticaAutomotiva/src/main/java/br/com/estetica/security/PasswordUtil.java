package br.com.estetica.security;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordUtil {

    public static String gerarHash(String senha) {
        return BCrypt.hashpw(senha, BCrypt.gensalt(12));
    }

    public static boolean verificarSenha(String senhaDigitada, String hashSalvo) {
        return BCrypt.checkpw(senhaDigitada, hashSalvo);
    }
}
package br.com.estetica.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import br.com.estetica.model.TipoServico;

public interface TipoServicoRepository extends MongoRepository<TipoServico, String> {

    List<TipoServico> findByAtivoTrue();
}
package br.com.estetica.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import br.com.estetica.model.PerfilUsuario;
import br.com.estetica.model.Usuario;
import br.com.estetica.repository.UsuarioRepository;
import br.com.estetica.security.PasswordUtil;

@Service
public class AuthService {

    private final UsuarioRepository usuarioRepository;

    public AuthService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public Usuario cadastrarUsuario(String email, String senha, PerfilUsuario perfil) {

        if (usuarioRepository.existsByEmail(email)) {
            throw new RuntimeException("E-mail já cadastrado.");
        }

        String senhaHash = PasswordUtil.gerarHash(senha);

        Usuario usuario = new Usuario(email, senhaHash, perfil);

        return usuarioRepository.save(usuario);
    }

    public Usuario login(String email, String senha) {

        Optional<Usuario> usuarioOptional = usuarioRepository.findByEmail(email);

        if (usuarioOptional.isEmpty()) {
            throw new RuntimeException("Usuário não encontrado.");
        }

        Usuario usuario = usuarioOptional.get();

        if (!usuario.isAtivo()) {
            throw new RuntimeException("Usuário inativo.");
        }

        boolean senhaCorreta = PasswordUtil.verificarSenha(senha, usuario.getSenhaHash());

        if (!senhaCorreta) {
            throw new RuntimeException("Senha incorreta.");
        }

        return usuario;
    }
}
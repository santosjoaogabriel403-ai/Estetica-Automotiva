package br.com.estetica.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import br.com.estetica.model.Cliente;

public interface ClienteRepository extends MongoRepository<Cliente, String> {

    Optional<Cliente> findByUsuarioId(String usuarioId);

    Optional<Cliente> findByCpf(String cpf);

    boolean existsByCpf(String cpf);

    boolean existsByEmail(String email);
}
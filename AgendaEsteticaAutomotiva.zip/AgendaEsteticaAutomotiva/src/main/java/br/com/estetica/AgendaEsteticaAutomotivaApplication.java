package br.com.estetica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendaEsteticaAutomotivaApplication {

    public static void main(String[] args) {
        SpringApplication.run(AgendaEsteticaAutomotivaApplication.class, args);
    }
}
package br.com.estetica.model;

public enum PerfilUsuario {
    CLIENTE,
    GESTOR
}
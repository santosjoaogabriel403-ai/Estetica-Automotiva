package br.com.estetica.model;

public enum StatusAgendamento {
    AGENDADO,
    CANCELADO,
    CONCLUIDO
}
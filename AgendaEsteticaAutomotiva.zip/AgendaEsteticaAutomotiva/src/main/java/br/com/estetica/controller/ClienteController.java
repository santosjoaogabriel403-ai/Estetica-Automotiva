package br.com.estetica.controller;

import br.com.estetica.service.ClienteService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ClienteController {

    private final ClienteService clienteService;

    public ClienteController(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @GetMapping("/clientes")
    public String listarClientes(Model model, HttpSession session) {
        if (session.getAttribute("usuarioLogado") == null) {
            return "redirect:/login";
        }

        if (!"GESTOR".equals(session.getAttribute("perfil"))) {
            return "redirect:/home";
        }

        model.addAttribute("clientes", clienteService.listarTodos());
        model.addAttribute("clienteService", clienteService);

        return "clientes";
    }

    @GetMapping("/clientes/editar/{id}")
    public String telaEditar(@PathVariable("id") String id,
                             HttpSession session,
                             Model model) {

        if (session.getAttribute("usuarioLogado") == null) {
            return "redirect:/login";
        }

        if (!"GESTOR".equals(session.getAttribute("perfil"))) {
            return "redirect:/home";
        }

        model.addAttribute("cliente",
                clienteService.buscarPorId(id)
                        .orElseThrow(() -> new RuntimeException("Cliente não encontrado.")));

        return "cliente-form";
    }

    @PostMapping("/clientes/editar")
    public String editar(@RequestParam("id") String id,
                         @RequestParam("nome") String nome,
                         @RequestParam("telefone") String telefone,
                         @RequestParam("email") String email,
                         HttpSession session) {

        if (session.getAttribute("usuarioLogado") == null) {
            return "redirect:/login";
        }

        if (!"GESTOR".equals(session.getAttribute("perfil"))) {
            return "redirect:/home";
        }

        clienteService.atualizarCliente(id, nome, telefone, email);

        return "redirect:/clientes";
    }

    @GetMapping("/clientes/excluir/{id}")
    public String excluirCliente(@PathVariable("id") String id, HttpSession session) {
        if (session.getAttribute("usuarioLogado") == null) {
            return "redirect:/login";
        }

        if (!"GESTOR".equals(session.getAttribute("perfil"))) {
            return "redirect:/home";
        }

        clienteService.excluirDefinitivo(id);
        return "redirect:/clientes";
    }
}
package br.com.estetica.model;

import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "agendamentos")
public class Agendamento {

    @Id
    private String id;

    private String clienteId;
    private String tipoServicoId;

    private String nomeCliente;
    private String nomeServico;
    private String placaVeiculo;

    private LocalDateTime dataHora;

    private StatusAgendamento status = StatusAgendamento.AGENDADO;

    public Agendamento() {
    }

    public Agendamento(String clienteId, String tipoServicoId, String nomeCliente,
                       String nomeServico, String placaVeiculo, LocalDateTime dataHora) {
        this.clienteId = clienteId;
        this.tipoServicoId = tipoServicoId;
        this.nomeCliente = nomeCliente;
        this.nomeServico = nomeServico;
        this.placaVeiculo = placaVeiculo;
        this.dataHora = dataHora;
        this.status = StatusAgendamento.AGENDADO;
    }

    public String getId() {
        return id;
    }

    public String getClienteId() {
        return clienteId;
    }

    public String getTipoServicoId() {
        return tipoServicoId;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public String getNomeServico() {
        return nomeServico;
    }

    public String getPlacaVeiculo() {
        return placaVeiculo;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public StatusAgendamento getStatus() {
        return status;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setClienteId(String clienteId) {
        this.clienteId = clienteId;
    }

    public void setTipoServicoId(String tipoServicoId) {
        this.tipoServicoId = tipoServicoId;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public void setNomeServico(String nomeServico) {
        this.nomeServico = nomeServico;
    }

    public void setPlacaVeiculo(String placaVeiculo) {
        this.placaVeiculo = placaVeiculo;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public void setStatus(StatusAgendamento status) {
        this.status = status;
    }
}
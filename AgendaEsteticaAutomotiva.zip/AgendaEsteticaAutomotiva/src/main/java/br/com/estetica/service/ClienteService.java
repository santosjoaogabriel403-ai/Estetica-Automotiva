package br.com.estetica.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import br.com.estetica.model.Cliente;
import br.com.estetica.model.PerfilUsuario;
import br.com.estetica.model.Usuario;
import br.com.estetica.model.Veiculo;
import br.com.estetica.repository.ClienteRepository;

@Service
public class ClienteService {

    private final ClienteRepository clienteRepository;
    private final AuthService authService;

    public ClienteService(ClienteRepository clienteRepository, AuthService authService) {
        this.clienteRepository = clienteRepository;
        this.authService = authService;
    }

    public Cliente cadastrarCliente(String nome, String cpf, String telefone, String email,
                                    String senha, String placa, String modeloVeiculo) {

        if (clienteRepository.existsByCpf(cpf)) {
            throw new RuntimeException("CPF já cadastrado.");
        }

        if (clienteRepository.existsByEmail(email)) {
            throw new RuntimeException("E-mail já cadastrado.");
        }

        Usuario usuario = authService.cadastrarUsuario(email, senha, PerfilUsuario.CLIENTE);

        Cliente cliente = new Cliente(usuario.getId(), nome, cpf, telefone, email);
        cliente.getVeiculos().add(new Veiculo(placa, modeloVeiculo));

        return clienteRepository.save(cliente);
    }

    public List<Cliente> listarTodos() {
        return clienteRepository.findAll();
    }

    public Optional<Cliente> buscarPorId(String id) {
        return clienteRepository.findById(id);
    }

    public Optional<Cliente> buscarPorUsuarioId(String usuarioId) {
        return clienteRepository.findByUsuarioId(usuarioId);
    }

    public Cliente atualizarCliente(String id, String nome, String telefone, String email) {

        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cliente não encontrado."));

        cliente.setNome(nome);
        cliente.setTelefone(telefone);
        cliente.setEmail(email);

        return clienteRepository.save(cliente);
    }

    public void excluirDefinitivo(String id) {
        clienteRepository.deleteById(id);
    }

    public String mascararCpf(String cpf) {
        if (cpf == null || cpf.length() < 11) {
            return "***";
        }

        return cpf.substring(0, 3) + ".***.***-" + cpf.substring(9);
    }

    public String mascararTelefone(String telefone) {
        if (telefone == null || telefone.length() < 4) {
            return "****";
        }

        return "*****-" + telefone.substring(telefone.length() - 4);
    }

    public String mascararEmail(String email) {
        if (email == null || !email.contains("@")) {
            return "***";
        }

        String[] partes = email.split("@");
        String nome = partes[0];

        if (nome.length() <= 2) {
            return "**@" + partes[1];
        }

        return nome.substring(0, 2) + "***@" + partes[1];
    }
}
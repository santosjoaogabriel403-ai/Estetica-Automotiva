package br.com.estetica.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import br.com.estetica.model.Agendamento;
import br.com.estetica.model.Cliente;
import br.com.estetica.model.StatusAgendamento;
import br.com.estetica.model.TipoServico;
import br.com.estetica.repository.AgendamentoRepository;
import br.com.estetica.repository.ClienteRepository;

@Service
public class AgendamentoService {

    private final AgendamentoRepository agendamentoRepository;
    private final ClienteRepository clienteRepository;
    private final TipoServicoService tipoServicoService;

    public AgendamentoService(AgendamentoRepository agendamentoRepository,
                              ClienteRepository clienteRepository,
                              TipoServicoService tipoServicoService) {
        this.agendamentoRepository = agendamentoRepository;
        this.clienteRepository = clienteRepository;
        this.tipoServicoService = tipoServicoService;
    }

    public Agendamento agendar(String clienteId, String tipoServicoId,
                               String placaVeiculo, LocalDateTime dataHora) {

        boolean horarioOcupado = agendamentoRepository
                .existsByDataHoraAndStatus(dataHora, StatusAgendamento.AGENDADO);

        if (horarioOcupado) {
            throw new RuntimeException("Horário indisponível. Já existe agendamento nesse horário.");
        }

        Cliente cliente = clienteRepository.findById(clienteId)
                .orElseThrow(() -> new RuntimeException("Cliente não encontrado."));

        TipoServico tipoServico = tipoServicoService.buscarPorId(tipoServicoId);

        Agendamento agendamento = new Agendamento(
                cliente.getId(),
                tipoServico.getId(),
                cliente.getNome(),
                tipoServico.getNome(),
                placaVeiculo,
                dataHora
        );

        return agendamentoRepository.save(agendamento);
    }

    public List<Agendamento> listarTodos() {
        return agendamentoRepository.findAll();
    }

    public List<Agendamento> listarPorCliente(String clienteId) {
        return agendamentoRepository.findByClienteId(clienteId);
    }

    public List<Agendamento> listarAgendaDia(LocalDate data) {
        LocalDateTime inicio = data.atStartOfDay();
        LocalDateTime fim = data.atTime(23, 59, 59);

        return agendamentoRepository.findByDataHoraBetween(inicio, fim);
    }

    public List<Agendamento> listarAgendaSemana(LocalDate dataInicial) {
        LocalDateTime inicio = dataInicial.atStartOfDay();
        LocalDateTime fim = dataInicial.plusDays(7).atStartOfDay();

        return agendamentoRepository.findByDataHoraBetween(inicio, fim);
    }

    public Agendamento buscarPorId(String id) {
        return agendamentoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Agendamento não encontrado."));
    }

    public Agendamento editarAgendamento(String id, String tipoServicoId,
                                         String placaVeiculo, LocalDateTime novaDataHora) {

        Agendamento agendamento = buscarPorId(id);

        if (!agendamento.getDataHora().equals(novaDataHora)) {
            boolean horarioOcupado = agendamentoRepository
                    .existsByDataHoraAndStatus(novaDataHora, StatusAgendamento.AGENDADO);

            if (horarioOcupado) {
                throw new RuntimeException("Novo horário indisponível.");
            }
        }

        TipoServico tipoServico = tipoServicoService.buscarPorId(tipoServicoId);

        agendamento.setTipoServicoId(tipoServico.getId());
        agendamento.setNomeServico(tipoServico.getNome());
        agendamento.setPlacaVeiculo(placaVeiculo);
        agendamento.setDataHora(novaDataHora);

        return agendamentoRepository.save(agendamento);
    }

    public void cancelar(String id) {
        Agendamento agendamento = buscarPorId(id);
        agendamento.setStatus(StatusAgendamento.CANCELADO);
        agendamentoRepository.save(agendamento);
    }

    public void concluir(String id) {
        Agendamento agendamento = buscarPorId(id);
        agendamento.setStatus(StatusAgendamento.CONCLUIDO);
        agendamentoRepository.save(agendamento);
    }
}
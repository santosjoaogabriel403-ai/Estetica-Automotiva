package br.com.estetica.config;

import br.com.estetica.model.PerfilUsuario;
import br.com.estetica.model.Usuario;
import br.com.estetica.repository.UsuarioRepository;
import br.com.estetica.security.PasswordUtil;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class AdminInitializer implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;

    public AdminInitializer(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    @Override
    public void run(String... args) {

        String emailAdmin = "admin@admin.com";

        if (!usuarioRepository.existsByEmail(emailAdmin)) {
            String senhaHash = PasswordUtil.gerarHash("admin123");

            Usuario admin = new Usuario(
                    emailAdmin,
                    senhaHash,
                    PerfilUsuario.GESTOR
            );

            usuarioRepository.save(admin);

            System.out.println("Gestor criado com sucesso!");
            System.out.println("Email: admin@admin.com");
            System.out.println("Senha: admin123");
        }
    }
}
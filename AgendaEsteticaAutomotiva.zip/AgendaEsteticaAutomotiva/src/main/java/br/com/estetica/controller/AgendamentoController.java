package br.com.estetica.controller;

import br.com.estetica.model.Cliente;
import br.com.estetica.model.Usuario;
import br.com.estetica.service.AgendamentoService;
import br.com.estetica.service.ClienteService;
import br.com.estetica.service.TipoServicoService;
import jakarta.servlet.http.HttpSession;
import java.time.LocalDate;
import java.time.LocalDateTime;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AgendamentoController {

    private final AgendamentoService agendamentoService;
    private final ClienteService clienteService;
    private final TipoServicoService tipoServicoService;

    public AgendamentoController(AgendamentoService agendamentoService,
                                 ClienteService clienteService,
                                 TipoServicoService tipoServicoService) {
        this.agendamentoService = agendamentoService;
        this.clienteService = clienteService;
        this.tipoServicoService = tipoServicoService;
    }

    @GetMapping("/agendamentos")
    public String listar(Model model, HttpSession session) {
        if (session.getAttribute("usuarioLogado") == null) return "redirect:/login";

        String perfil = String.valueOf(session.getAttribute("perfil"));

        if ("GESTOR".equals(perfil)) {
            model.addAttribute("agendamentos", agendamentoService.listarTodos());
        } else {
            Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
            Cliente cliente = clienteService.buscarPorUsuarioId(usuario.getId())
                    .orElseThrow(() -> new RuntimeException("Cliente não encontrado."));
            model.addAttribute("agendamentos", agendamentoService.listarPorCliente(cliente.getId()));
        }

        model.addAttribute("perfil", perfil);
        return "agendamentos";
    }

    @GetMapping("/agendamentos/novo")
    public String novo(Model model, HttpSession session) {
        if (session.getAttribute("usuarioLogado") == null) return "redirect:/login";

        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
        Cliente cliente = clienteService.buscarPorUsuarioId(usuario.getId()).orElse(null);

        model.addAttribute("cliente", cliente);
        model.addAttribute("servicos", tipoServicoService.listarAtivos());
        return "agendamento-form";
    }

    @PostMapping("/agendamentos")
    public String salvar(@RequestParam("tipoServicoId") String tipoServicoId,
                         @RequestParam("placaVeiculo") String placaVeiculo,
                         @RequestParam("dataHora") String dataHora,
                         HttpSession session,
                         Model model) {
        try {
            Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
            Cliente cliente = clienteService.buscarPorUsuarioId(usuario.getId())
                    .orElseThrow(() -> new RuntimeException("Cliente não encontrado."));

            agendamentoService.agendar(cliente.getId(), tipoServicoId, placaVeiculo, LocalDateTime.parse(dataHora));
            return "redirect:/agendamentos";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            model.addAttribute("servicos", tipoServicoService.listarAtivos());
            return "agendamento-form";
        }
    }

    @GetMapping("/agendamentos/editar/{id}")
    public String telaEditar(@PathVariable("id") String id, Model model, HttpSession session) {
        if (session.getAttribute("usuarioLogado") == null) return "redirect:/login";

        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
        Cliente cliente = clienteService.buscarPorUsuarioId(usuario.getId()).orElse(null);

        model.addAttribute("agendamento", agendamentoService.buscarPorId(id));
        model.addAttribute("cliente", cliente);
        model.addAttribute("servicos", tipoServicoService.listarAtivos());

        return "agendamento-editar";
    }

    @PostMapping("/agendamentos/editar")
    public String editar(@RequestParam("id") String id,
                         @RequestParam("tipoServicoId") String tipoServicoId,
                         @RequestParam("placaVeiculo") String placaVeiculo,
                         @RequestParam("dataHora") String dataHora,
                         HttpSession session,
                         Model model) {
        try {
            agendamentoService.editarAgendamento(id, tipoServicoId, placaVeiculo, LocalDateTime.parse(dataHora));
            return "redirect:/agendamentos";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            model.addAttribute("servicos", tipoServicoService.listarAtivos());
            return "agendamento-editar";
        }
    }

    @GetMapping("/agendamentos/cancelar/{id}")
    public String cancelar(@PathVariable("id") String id, HttpSession session) {
        if (session.getAttribute("usuarioLogado") == null) return "redirect:/login";
        agendamentoService.cancelar(id);
        return "redirect:/agendamentos";
    }

    @GetMapping("/agendamentos/concluir/{id}")
    public String concluir(@PathVariable("id") String id, HttpSession session) {
        if (session.getAttribute("usuarioLogado") == null) return "redirect:/login";
        if (!"GESTOR".equals(session.getAttribute("perfil"))) return "redirect:/home";

        agendamentoService.concluir(id);
        return "redirect:/agendamentos";
    }

    @GetMapping("/agendamentos/dia")
    public String agendaDia(@RequestParam(value = "data", required = false) String data,
                            Model model,
                            HttpSession session) {
        if (session.getAttribute("usuarioLogado") == null) return "redirect:/login";
        if (!"GESTOR".equals(session.getAttribute("perfil"))) return "redirect:/home";

        LocalDate dataBusca = data == null || data.isBlank() ? LocalDate.now() : LocalDate.parse(data);

        model.addAttribute("agendamentos", agendamentoService.listarAgendaDia(dataBusca));
        model.addAttribute("data", dataBusca);
        return "agenda-dia";
    }

    @GetMapping("/agendamentos/semana")
    public String agendaSemana(@RequestParam(value = "data", required = false) String data,
                                Model model,
                                HttpSession session) {
        if (session.getAttribute("usuarioLogado") == null) return "redirect:/login";
        if (!"GESTOR".equals(session.getAttribute("perfil"))) return "redirect:/home";

        LocalDate dataBusca = data == null || data.isBlank() ? LocalDate.now() : LocalDate.parse(data);

        model.addAttribute("agendamentos", agendamentoService.listarAgendaSemana(dataBusca));
        model.addAttribute("data", dataBusca);
        return "agenda-semana";
    }
}
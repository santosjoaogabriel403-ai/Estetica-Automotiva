package br.com.estetica.controller;

import br.com.estetica.model.Usuario;
import br.com.estetica.service.AuthService;
import br.com.estetica.service.ClienteService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    private final AuthService authService;
    private final ClienteService clienteService;

    public AuthController(AuthService authService, ClienteService clienteService) {
        this.authService = authService;
        this.clienteService = clienteService;
    }

    @GetMapping("/login")
    public String telaLogin() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam("email") String email,
                        @RequestParam("senha") String senha,
                        HttpSession session,
                        Model model) {
        try {
            Usuario usuario = authService.login(email, senha);

            session.setAttribute("usuarioLogado", usuario);
            session.setAttribute("usuarioId", usuario.getId());
            session.setAttribute("perfil", usuario.getPerfil().name());

            return "redirect:/home";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "login";
        }
    }

    @GetMapping("/cadastro")
    public String telaCadastro() {
        return "cadastro";
    }

    @PostMapping("/cadastro")
    public String cadastrar(@RequestParam("nome") String nome,
                            @RequestParam("cpf") String cpf,
                            @RequestParam("telefone") String telefone,
                            @RequestParam("email") String email,
                            @RequestParam("senha") String senha,
                            @RequestParam("placa") String placa,
                            @RequestParam("modeloVeiculo") String modeloVeiculo,
                            Model model) {
        try {
            clienteService.cadastrarCliente(nome, cpf, telefone, email, senha, placa, modeloVeiculo);
            model.addAttribute("sucesso", "Cliente cadastrado com sucesso. Faça login.");
            return "login";
        } catch (RuntimeException e) {
            model.addAttribute("erro", e.getMessage());
            return "cadastro";
        }
    }

    @GetMapping("/home")
    public String home(HttpSession session, Model model) {
        Object usuario = session.getAttribute("usuarioLogado");

        if (usuario == null) {
            return "redirect:/login";
        }

        model.addAttribute("perfil", session.getAttribute("perfil"));
        return "home";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
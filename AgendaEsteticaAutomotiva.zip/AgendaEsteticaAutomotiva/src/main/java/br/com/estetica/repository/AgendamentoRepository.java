package br.com.estetica.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import br.com.estetica.model.Agendamento;
import br.com.estetica.model.StatusAgendamento;

public interface AgendamentoRepository extends MongoRepository<Agendamento, String> {

    List<Agendamento> findByClienteId(String clienteId);

    List<Agendamento> findByDataHoraBetween(LocalDateTime inicio, LocalDateTime fim);

    boolean existsByDataHoraAndStatus(LocalDateTime dataHora, StatusAgendamento status);

    List<Agendamento> findByStatus(StatusAgendamento status);
}
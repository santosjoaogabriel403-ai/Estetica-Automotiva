package br.com.estetica.service;

import java.util.List;

import org.springframework.stereotype.Service;

import br.com.estetica.model.TipoServico;
import br.com.estetica.repository.TipoServicoRepository;

@Service
public class TipoServicoService {

    private final TipoServicoRepository tipoServicoRepository;

    public TipoServicoService(TipoServicoRepository tipoServicoRepository) {
        this.tipoServicoRepository = tipoServicoRepository;
    }

    public TipoServico cadastrar(String nome, String descricao, Double preco) {

        if (nome == null || nome.isBlank()) {
            throw new RuntimeException("Nome do serviço é obrigatório.");
        }

        if (preco == null || preco <= 0) {
            throw new RuntimeException("Preço inválido.");
        }

        TipoServico tipoServico = new TipoServico(nome, descricao, preco);

        return tipoServicoRepository.save(tipoServico);
    }

    public List<TipoServico> listarAtivos() {
        return tipoServicoRepository.findByAtivoTrue();
    }

    public List<TipoServico> listarTodos() {
        return tipoServicoRepository.findAll();
    }

    public TipoServico buscarPorId(String id) {
        return tipoServicoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Tipo de serviço não encontrado."));
    }

    public TipoServico atualizar(String id, String nome, String descricao, Double preco) {

        TipoServico tipoServico = buscarPorId(id);

        tipoServico.setNome(nome);
        tipoServico.setDescricao(descricao);
        tipoServico.setPreco(preco);

        return tipoServicoRepository.save(tipoServico);
    }

    public void desativar(String id) {
        TipoServico tipoServico = buscarPorId(id);
        tipoServico.setAtivo(false);
        tipoServicoRepository.save(tipoServico);
    }
}